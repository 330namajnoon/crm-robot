
window.env = {
    // SERVER_URL: "https://sinul.es/macserver",
    // SERVER_URL: "https://98b63tn1-4000.euw.devtunnels.ms",
    SERVER_URL: "http://localhost:4000",
    HEADERS: {
        'Content-Type': 'application/json',
    },
}